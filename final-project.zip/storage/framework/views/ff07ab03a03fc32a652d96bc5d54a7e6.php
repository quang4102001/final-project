<div id="sidebar" class="border-end py-[45px] pl-[45px]">
    <div id="cart">
        <header class="d-flex justify-content-between">
            <span id="cart-icon" class="d-flex align-items-center">
                <h2 class="fw-bold mr-2">Cart</h2>
                <img src="<?php echo e(asset('images/icons/cart.png')); ?>" alt="cart-icon" />
            </span>
            <a href="<?php echo e(route('user.cart')); ?>" id="checkout"
                class="border-2 border-[#5ff7d2] text-uppercase fw-bold text-[1.3rem] leading-1 px-3 py-1 text-[#5ff7d2] mr-[45px] hover:text-white hover:bg-[#5ff7d2]">
                Checkout
            </a>
        </header>
        <div id="cart-list" class="max-h-[300px] overflow-auto my-3">
            <?php if(session('cartUser')): ?>
                <?php $__currentLoopData = session('cartUser'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php for($i = 0; $i < $item['qty']; $i++): ?>
                        <div class="cart-item mt-4 relative">
                            <div class="d-flex items-center">
                                <div class="bg-[url('<?php echo e($item['img']); ?>')] w-[50px] h-[50px] bg-cover">
                                </div>
                                <div class="flex-1 ml-5 pr-[45px]">
                                    <p class="cart-item-title"><?php echo e($item['name']); ?></p>
                                    <p class="cart-item-title text-[#5ff7d2] fw-bold">$<?php echo e($item['price']); ?></p>
                                </div>
                            </div>
                            <div class="cart-item-border mr-[45px] border-bottom mt-3"></div>
                            <i data-id="<?php echo e($item['productId']); ?>" data-colorId="<?php echo e($item['colorId']); ?>"
                                class="fa-solid fa-xmark cart-item-close hidden cursor-pointer absolute right-[18px] top-[8px] text-[2rem] text-[#ccc] p-3"></i>
                        </div>
                    <?php endfor; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php for($i = 0; $i < $item['qty']; $i++): ?>
                        <div class="cart-item mt-4 relative">
                            <div class="d-flex items-center">
                                <div class="bg-[url('<?php echo e($item['img']); ?>')] w-[50px] h-[50px] bg-cover">
                                </div>
                                <div class="flex-1 ml-5 pr-[45px]">
                                    <p class="cart-item-title"><?php echo e($item['name']); ?></p>
                                    <p class="cart-item-title text-[#5ff7d2] fw-bold">$<?php echo e($item['price']); ?></p>
                                </div>
                            </div>
                            <div class="cart-item-border mr-[45px] border-bottom mt-3"></div>
                            <i data-id="<?php echo e($item['productId']); ?>" data-colorId="<?php echo e($item['colorId']); ?>"
                                class="fa-solid fa-xmark cart-item-close hidden cursor-pointer absolute right-[18px] top-[8px] text-[2rem] text-[#ccc] p-3"></i>
                        </div>
                    <?php endfor; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <p id="cart-no-item" class="py-2 hidden">
                <i class="text-[#ccc]">No item in cart.</i>
            </p>
        </div>
    </div>
    <div id="category-list" class="block mt-[45px]">
        <h2 class="category-title fw-bold tracking-[1px] text-uppercase mb-2">Category</h2>
        <ul>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(request()->categories): ?>
                    <li class="py-2">
                        <input type="checkbox" id="<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>" class="filter"
                            name="categories[]"
                            <?php echo e(in_array($category->id, explode(',', request()->categories)) ? 'checked' : ''); ?>>
                        <label class="ml-3 text-[#676a74] hover:text-[#333]"
                            for="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
                    </li>
                <?php else: ?>
                    <li class="py-2">
                        <input type="checkbox" id="<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>" class="filter"
                            name="categories[]">
                        <label class="ml-3 text-[#676a74] hover:text-[#333]"
                            for="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="py-2">
                    <i class="text-[#ccc]">No item in categories.</i>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    <div id="colors-list" class="block mt-[45px]">
        <h2 class="color-title fw-bold tracking-[1px] text-uppercase mb-2">Colors</h2>
        <ul class="row row-cols-4">
            <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(request()->colors): ?>
                    <li class="py-2">
                        <input class="color-item-radio hidden filter" type="checkbox" id="<?php echo e($color->id); ?>"
                            <?php echo e(in_array($color->id, explode(',', request()->colors)) ? 'checked' : ''); ?>>
                        <label class="color-item-label rounded-full p-[2px] border-[1px] border-transparent shadow-sm"
                            for="<?php echo e($color->id); ?>">
                            <div class="rounded-full w-[2rem] h-[2rem] bg-[<?php echo e($color->name); ?>] shadow-sm"></div>
                        </label>
                    </li>
                <?php else: ?>
                    <li class="py-2">
                        <input class="color-item-radio hidden filter" type="checkbox" id="<?php echo e($color->id); ?>">
                        <label class="color-item-label rounded-full p-[2px] border-[1px] border-transparent shadow-sm"
                            for="<?php echo e($color->id); ?>">
                            <div class="rounded-full w-[2rem] h-[2rem] bg-[<?php echo e($color->name); ?>] shadow-sm"></div>
                        </label>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="py-2">
                    <i class="text-[#ccc]">No item in colors.</i>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    <div id="sizes-list" class="block mt-[45px]">
        <h2 class="size-title fw-bold tracking-[1px] text-uppercase mb-2">Sizes</h2>
        <ul class="row row-cols-2">
            <?php $__empty_1 = true; $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if(request()->sizes): ?>
                    <li class="py-2">
                        <input class="input-size filter" type="checkbox" id="<?php echo e($size->id); ?>"
                            <?php echo e(in_array($size->id, explode(',', request()->sizes)) ? 'checked' : ''); ?>>
                        <label class="ml-3 text-[#676a74] hover:text-[#333]"
                            for="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></label>
                    </li>
                <?php else: ?>
                    <li class="py-2">
                        <input class="input-size filter" type="checkbox" id="<?php echo e($size->id); ?>">
                        <label class="ml-3 text-[#676a74] hover:text-[#333]"
                            for="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></label>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="py-2">
                    <i class="text-[#ccc]">No item in sizes.</i>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    <div id="prices-list" class="block mt-[45px]">
        <h2 class="price-title fw-bold tracking-[1px] text-uppercase mb-2">Price range</h2>
        <img class="py-2" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/245657/price-range.png" alt="price-img">
    </div>
</div>

<script>
    $(document).ready(function() {
        if ($("#cart-list .cart-item").size() == 0) {
            $("#cart-no-item").fadeIn(500);
            $("#checkout").fadeOut(500);
        }

        const filterProducts = function(value, param) {
            // Lấy URL hiện tại
            var currentUrl = window.location.href;

            // Kiểm tra xem có tham số truy vấn trong URL không
            var queryIndex = currentUrl.indexOf('?');
            var queryString = queryIndex !== -1 ? currentUrl.substring(queryIndex + 1) : '';

            // Chuyển tham số truy vấn thành một đối tượng
            var params = {};
            queryString.split('&').forEach(function(pair) {
                pair = pair.split('=');
                params[pair[0]] = pair[1];
            });

            // Thêm hoặc cập nhật giá trị 'pagination' trong đối tượng tham số truy vấn
            params[param] = value

            // Xây dựng URL mới với tham số truy vấn cập nhật
            var newUrl = currentUrl.split('?')[0] + '?' + Object.keys(params).map(function(
                key) {
                return key + '=' + params[key];
            }).join('&');

            // Chuyển hướng đến URL mới
            window.location.href = newUrl;
        }

        let filterTimer = 0;

        $('#category-list .filter').each(function() {
            $(this).change(function() {
                clearTimeout(filterTimer)
                var categories = []
                $('#category-list .filter:checked').each(function() {
                    categories.push($(this).val())
                })
                filterTimer = setTimeout(function() {
                    filterProducts(categories, 'categories')
                }, 1000)
            })
        })

        $('#colors-list .filter').each(function() {
            $(this).change(function() {
                clearTimeout(filterTimer)
                var colors = []
                $('#colors-list .filter:checked').each(function() {
                    colors.push($(this).attr('id'))
                })
                filterTimer = setTimeout(function() {
                    filterProducts(colors, 'colors')
                }, 1000)
            })
        })

        $('#sizes-list .filter').each(function() {
            $(this).change(function() {
                clearTimeout(filterTimer)
                var sizes = []
                $('#sizes-list .filter:checked').each(function() {
                    sizes.push($(this).attr('id'))
                })
                filterTimer = setTimeout(function() {
                    filterProducts(sizes, 'sizes')
                }, 1000)
            })
        })

        $("#cart-list .cart-item-close").each(function() {
            $(this).off('click').on('click', function() {
                const productId = $(this).attr('data-id');
                const colorId = $(this).attr('data-colorId');
                exceptFromCart(productId, colorId);
                $(this).closest(".cart-item").fadeOut(300, function() {
                    $(this).remove();
                    if ($("#cart-list .cart-item").size() == 0) {
                        $("#cart-no-item").fadeIn(500);
                        $("#checkout").fadeOut(500);
                    }
                });
            });
        })
    })
</script>
<?php /**PATH D:\laragon\www\deploy\final-project\resources\views/home/sidebar/sidebar.blade.php ENDPATH**/ ?>