@extends('admin.layout')

@section('admin')
    @include('admin.products.detail')
@endsection
