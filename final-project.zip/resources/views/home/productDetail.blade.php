@extends('home.layout')

@section('users')
    @include('admin.products.detail')
@endsection
