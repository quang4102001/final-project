<?php
return [
    'pagination' => 50,
];